/*
File    : 02-printf-sleep.cpp
Tác giả : Nguyễn Trung Thành - https://www.facebook.com/thanh.it95

Mô tả   : in ra màn hình một dòng chữ, áp dụng lệnh printf (in ra theo định dạng) và lệnh sleep để tạm ngừng thời gian
Mục đích: demo minh họa sử dụng thư viện cobe, giúp bạn hiểu hơn về thư viện cobe
*/

#include "cobe.hpp"
using namespace libcobe;

CobeManager &cobe = initcobe();

int main()
{
    cobe.resizeScreen(80, 24);

    char str[] = "Hom nay, co giao day em doan ket, thuong yeu, giup do ban be.";

    for (int i = 0; str[i]; ++i)
    {
        cobe.printfAndUpdate(2 + i, 2, "%c", str[i]);
        cobe.sleep(100);
    }

    return 0;
}
