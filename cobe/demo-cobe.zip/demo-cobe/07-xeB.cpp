﻿/*
File    : 07-xeB.cpp
Tác giả : Nguyễn Trung Thành - https://www.facebook.com/thanh.it95

Mô tả   : game đua xe hoàn chỉnh ở mức độ đơn giản nhất
Mục đích: demo minh họa sử dụng thư viện cobe, giúp bạn hiểu hơn về thư viện cobe

Để chạy game tốt, các phần mềm gõ tiếng Việt như Unikey, EVKey,... bạn vui lòng vô hiệu hóa (chuyển sang chế độ gõ tiếng Anh)

Hướng dẫn sử dụng: nhấn các phím A và D để điều khiển xe chạy sang trái hoặc sang phải, nhấn phím Space (khoảng trắng) để bắn đạn
*/


#include <vector>
using namespace std;

#include "cobe.hpp"
using namespace libcobe;


CobeManager &cobe = initcobe();


int consoleWidth = 0;
int consoleHeight = 0;
int gameWidth = 30;


struct Xe
{
    CoVect toaDo;           // tọa độ tại trung tâm xe
    vector<CoVect> dsDan;   // danh sách đạn đang bắn ra
};

struct ChuongNgaiVat
{
    CoVect toaDo;           // tọa độ tại trung tâm
};

struct GameData
{
    Xe xe;
    int diemPlayer;         // điểm số của player
    vector<ChuongNgaiVat> dsChuongNgaiVat;
};


void KhoiTao(GameData &data)
{
    data.xe.toaDo.x = (gameWidth + 1) / 2;
    data.xe.toaDo.y = consoleHeight - 2;
    data.dsChuongNgaiVat.clear();
    data.diemPlayer = 0;
}


void HienThi(GameData &data)
{
    // vẽ chướng ngại vật
    cobe.setForegroundColor(CoColor::WHITE);
    for (int i = 0; i < (int)data.dsChuongNgaiVat.size(); ++i)
    {
        ChuongNgaiVat &cnv = data.dsChuongNgaiVat[i];
        cobe.print(cnv.toaDo.x - 1, cnv.toaDo.y - 1, "***");
        cobe.print(cnv.toaDo.x - 1, cnv.toaDo.y, "***");
        cobe.print(cnv.toaDo.x - 1, cnv.toaDo.y + 1, "***");
    }

    // vẽ đạn
    cobe.setForegroundColor(CoColor::LIGHT_GREEN);
    for (int i = 0; i < (int)data.xe.dsDan.size(); ++i)
    {
        CoVect &toaDo = data.xe.dsDan[i];
        cobe.print(toaDo.x, toaDo.y, "x");
    }

    // vẽ xe
    cobe.setForegroundColor(CoColor::LIGHT_YELLOW);
    cobe.print(data.xe.toaDo.x, data.xe.toaDo.y - 1, "#");
    cobe.print(data.xe.toaDo.x - 1, data.xe.toaDo.y, "###");
    cobe.print(data.xe.toaDo.x - 1, data.xe.toaDo.y + 1, "# #");

    // vẽ biên
    cobe.setForegroundColor(CoColor::DARK_GRAY);
    for (int i = 0; i < consoleHeight; ++i)
    {
        cobe.print(1, i, "|");
        cobe.print(gameWidth + 1, i, "|");
    }

    cobe.setForegroundColor(CoColor::WHITE);
    cobe.print(gameWidth + 4, 3, "A: sang trai   P: sang phai   Space: ban dan");
    cobe.printf(gameWidth + 4, 5, "Diem so: %d", data.diemPlayer);
}


void XuLyDieuKhien(Xe &xe)
{
    if (cobe.getKey('A') && xe.toaDo.x > 4)
        xe.toaDo.x -= 2;

    if (cobe.getKey('D') && xe.toaDo.x < gameWidth - 2)
        xe.toaDo.x += 2;

    if (cobe.getKey(' ') && xe.dsDan.size() < 4)
    {
        // khi nhấn phím SPACE (khoảng trắng) thì bắn đạn
        CoVect toaDoDan = { xe.toaDo.x, xe.toaDo.y - 2 };
        xe.dsDan.push_back(toaDoDan);
    }
}


// return 1 nếu bình thường, return 0 nếu thua game
int XuLyChung(GameData &data)
{
    Xe &xe = data.xe;
    vector<ChuongNgaiVat> &dsChuongNgaiVat = data.dsChuongNgaiVat;


    // XỬ LÝ VA CHẠM
    for (int i = dsChuongNgaiVat.size() - 1; i >= 0; --i)
    {
        ChuongNgaiVat &cnv = dsChuongNgaiVat[i];

        // KIỂM TRA CHƯỚNG NGẠI VẬT cnv VA CHẠM XE PLAYER
        int dx = abs(xe.toaDo.x - cnv.toaDo.x);
        int dy = abs(xe.toaDo.y - cnv.toaDo.y);

        if (dx < 3 && dy < 3)
            return 0; // thua game

        // KIỂM TRA CHƯỚNG NGẠI VẬT cnv VA CHẠM ĐẠN
        for (int j = xe.dsDan.size() - 1; j >= 0; --j)
        {
            CoVect &toaDoDan = xe.dsDan[j];
            int dx = abs(toaDoDan.x - cnv.toaDo.x);
            int dy = abs(toaDoDan.y - cnv.toaDo.y);

            if (dx < 2 && dy < 2)
            {
                // đạn va chạm chướng ngại vật
                xe.dsDan.erase(xe.dsDan.begin() + j);
                dsChuongNgaiVat.erase(dsChuongNgaiVat.begin() + i);
                ++data.diemPlayer;
                break;
            }
        }
    }


    // TẠO THÊM CHƯỚNG NGẠI VẬT
    if (dsChuongNgaiVat.size() < 5 && cobe_random(1, 5) == 1)
    {
        ChuongNgaiVat cnv;
        cnv.toaDo.x = cobe_random(3, gameWidth - 1);
        cnv.toaDo.y = 0;
        dsChuongNgaiVat.push_back(cnv);
    }

    // DỊCH CHUYỂN CHƯỚNG NGẠI VẬT XUỐNG DƯỚI
    for (int i = dsChuongNgaiVat.size() - 1; i >= 0; --i)
    {
        ChuongNgaiVat &cnv = dsChuongNgaiVat[i];
        ++cnv.toaDo.y;

        // kiểm tra chướng ngại vật đã xuống biên phía dưới
        if (cnv.toaDo.y >= consoleHeight + 2) {
            dsChuongNgaiVat.erase(dsChuongNgaiVat.begin() + i);
            ++data.diemPlayer;
        }
    }

    // DỊCH CHUYỂN ĐẠN CỦA XE PLAYER LÊN TRÊN
    for (int i = xe.dsDan.size() - 1; i >= 0; --i)
    {
        CoVect &toaDoDan = xe.dsDan[i];

        if (toaDoDan.y - 1 <= 1) { // chạm biên trên
            xe.dsDan.erase(xe.dsDan.begin() + i);
            continue;
        }

        --toaDoDan.y;
    }

    return 1;
}


int main()
{
    cobe.resizeScreen(90, 30);
    cobe.getScreenSize(consoleWidth, consoleHeight);  // lấy kích thước màn hình

    cobe.printAndUpdate(1, 1, "                GAME DUA XE                 ");
    cobe.printAndUpdate(1, 3, "A: sang trai   P: sang phai   Space: ban dan");
    cobe.printAndUpdate(1, 5, "Vui long vo hieu hoa phan mem go tieng Viet (Unikey, EVKey, ...)");
    cobe.printAndUpdate(1, 7, "Nhan phim Enter de bat dau choi game");
    cobe.pause(COKEY_ENTER);


    GameData data;
    KhoiTao(data);


    while (cobe.updateAndSleepFPS(35))
    {
        cobe.clearScreen();

        XuLyDieuKhien(data.xe);
        HienThi(data);

        int ret = XuLyChung(data);
        if (ret == 0)
            break;
    }

    cobe.printAndUpdate(gameWidth + 4, consoleHeight / 2 - 3, "        GAME OVER       ");
    cobe.printAndUpdate(gameWidth + 4, consoleHeight / 2 - 2, "Nhan phim ENTER de thoat");
    cobe.gotoxy(0, consoleHeight - 1);
    cobe.pause(COKEY_ENTER);

    return 0;
}
