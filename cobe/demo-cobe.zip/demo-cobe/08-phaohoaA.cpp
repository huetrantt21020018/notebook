﻿/*
File    : 08-phaohoaA.cpp
Tác giả : Nguyễn Trung Thành - https://www.facebook.com/thanh.it95

Mô tả   : hiệu ứng pháo hoa ở mức độ đơn giản nhất
Mục đích: demo minh họa sử dụng thư viện cobe, giúp bạn hiểu hơn về thư viện cobe
*/

#include "cobe.hpp"
using namespace libcobe;


CobeManager &cobe = initcobe();


int consoleWidth = 80;
int consoleHeight = 24;


void VePhaoHoa(int tamX, int tamY, int r)
{
    cobe.setForegroundColor(CoColor::getRandomColor());

    for (int i = -r; i <= r; ++i)
    {
        cobe.print(tamX + i, tamY, "*");
        cobe.print(tamX, tamY + i, "*");
        cobe.print(tamX + i, tamY + i, "*");
        cobe.print(tamX + i, tamY - i, "*");
    }
}

int main()
{
    cobe.resizeScreen(110, 30);
    cobe.getScreenSize(consoleWidth, consoleHeight);

    while (cobe.updateAndSleepFPS(1))
    {
        cobe.clearScreen();

        int r = 1 + rand() % 6;
        int tamX = cobe_random(1 + r, consoleWidth - 2 - r);
        int tamY = cobe_random(1 + r, consoleHeight - 2 - r);

        VePhaoHoa(tamX, tamY, r);
    }

    return 0;
}
