#include "cobe.hpp"
using namespace libcobe;

CobeManager &cobe = initcobe();

int main()
{
    cobe.printAndUpdate(2, 2, "Hello cobe");

    cobe.setForegroundColor(CoColor::LIGHT_CYAN);
    cobe.printAndUpdate(20, 2, "Chu mau xanh");

    cobe.setBackgroundColor(CoColor::PURPLE);
    cobe.printAndUpdate(2, 4, "Chu mau xanh tren nen tim");

    return 0;
}
