﻿/*
File    : 05-click.cpp
Tác giả : Nguyễn Trung Thành - https://www.facebook.com/thanh.it95

Mô tả   : vẽ ra hiệu ứng tại vị trí click chuột
Mục đích: demo minh họa sử dụng thư viện cobe, giúp bạn hiểu hơn về thư viện cobe
*/

#include "cobe.hpp"
using namespace libcobe;


CobeManager &cobe = initcobe();


// vẽ ra hiệu ứng tại tọa độ (tamX, tamY), bán kính là r
void VeHieuUng(int tamX, int tamY, int r)
{
    cobe.setForegroundColor(CoColor::getRandomColor());

    for (int i = -r; i <= r; ++i)
    {
        cobe.print(tamX + i, tamY, "*");
        cobe.print(tamX, tamY + i, "*");
        cobe.print(tamX + i, tamY + i, "*");
        cobe.print(tamX + i, tamY - i, "*");
    }
}

int main()
{
    cobe.resizeScreen(80, 24);

    CoMouseRecord record;

    while (cobe.updateAndSleepFPS(20))
    {
        cobe.clearScreen();
        cobe.print(1, 1, "Click 1 vi tri tren man hinh");

        if (cobe.getLastMouseRecord(record))
        {
            VeHieuUng(record.position.x, record.position.y, 4);
        }
    }

    return 0;
}
