﻿/*
File    : 06-shapes.cpp
Tác giả : Nguyễn Trung Thành - https://www.facebook.com/thanh.it95

Mô tả   : di chuyển chuột qua các hình để thấy hiệu ứng đổi màu
Mục đích: demo minh họa sử dụng thư viện cobe, giúp bạn hiểu hơn về thư viện cobe
*/

#include "cobe.hpp"
using namespace libcobe;

#include <vector>
using namespace std;


CobeManager &cobe = initcobe();


int main()
{
    cobe.resizeScreen(80, 24);

    vector<CoShape> listShapes;

    listShapes.push_back(CoShapeFactory::createRectangle(7, 4, 12, 5, 0, '#', "cobe"));
    listShapes.push_back(CoShapeFactory::createEllipse(31, 15, 12, 4, '*', "hello"));
    listShapes.push_back(CoShapeFactory::createTriangle(CoVect(50, 10), CoVect(60, 5), CoVect(64, 14), '.', "super"));
    listShapes.push_back(CoShapeFactory::createLine(50, 0, 75, 10));


    while (cobe.updateAndSleepFPS(20))
    {
        cobe.clearScreen();
        cobe.setForegroundColor(CoColor::WHITE);
        cobe.print(1, 1, "Move the mouse over the shapes, press ENTER to exit");

        if (cobe.getKey(13))
            break;

        CoVect mousePos = cobe.getLastMousePosition();

        for (vector<CoShape>::iterator it = listShapes.begin(); it != listShapes.end(); ++it)
        {
            cobe.setForegroundColor(CoColor::WHITE);

            if (it->checkPointInside(mousePos))
                cobe.setForegroundColor(CoColor::LIGHT_RED);

            cobe.print(*it);
        }
    }

    return 0;
}
