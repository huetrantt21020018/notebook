﻿/*
File    : 04-colorful.cpp
Tác giả : Nguyễn Trung Thành - https://www.facebook.com/thanh.it95

Mô tả   : hiển thị ngẫu nhiên các đốm sáng
Mục đích: demo minh họa sử dụng thư viện cobe, giúp bạn hiểu hơn về thư viện cobe
*/

#include "cobe.hpp"
using namespace libcobe;


CobeManager &cobe = initcobe();


int consoleWidth = 0;
int consoleHeight = 0;


int main()
{
    cobe.resizeScreen(80, 24);
    cobe.getScreenSize(consoleWidth, consoleHeight);

    while (cobe.update())
    {
        int x = 1 + rand() % (consoleWidth - 2);
        int y = 1 + rand() % (consoleHeight - 2);
        int color = CoColor::getRandomColor();

        cobe.setForegroundColor(color);

        cobe.print(x, y, "*");
    }

    return 0;
}
