﻿/*
File    : 07-xeA.cpp
Tác giả : Nguyễn Trung Thành - https://www.facebook.com/thanh.it95

Mô tả   : lập trình chức năng điều khiển xe trong game
Mục đích: demo minh họa sử dụng thư viện cobe, giúp bạn hiểu hơn về thư viện cobe

Để chạy tốt, các phần mềm gõ tiếng Việt như Unikey, EVKey,... bạn vui lòng vô hiệu hóa (chuyển sang chế độ gõ tiếng Anh)

Hướng dẫn sử dụng: nhấn các phím A và D để điều khiển xe chạy sang trái hoặc sang phải, nhấn phím Space (khoảng trắng) để bắn đạn
*/

#include "cobe.hpp"
using namespace libcobe;


CobeManager &cobe = initcobe();


int consoleWidth = 0;
int consoleHeight = 0;


int main()
{
    cobe.resizeScreen(90, 30);
    cobe.getScreenSize(consoleWidth, consoleHeight); // lấy kích thước màn hình => consoleWidth = 90, consoleHeight = 30

    CoVect toaDoXe;     // tọa độ tại trung tâm xe
    CoVect toaDoDan;    // tọa độ viên đạn bắn ra
    int dangBanDan = 0; // = 0 nếu đạn không bắn ra, = 1 nếu đang bắn ra

    toaDoXe.x = consoleWidth / 2;
    toaDoXe.y = consoleHeight - 2;


    while (cobe.updateAndSleepFPS(30))
    {
        cobe.clearScreen();

        // HIỂN THỊ XE VÀ ĐẠN
        cobe.print(toaDoXe.x, toaDoXe.y - 1, "#");
        cobe.print(toaDoXe.x - 1, toaDoXe.y, "###");
        cobe.print(toaDoXe.x - 1, toaDoXe.y + 1, "# #");

        if (dangBanDan == 1)
            cobe.print(toaDoDan.x, toaDoDan.y, "x");

        // XỬ LÝ PHÍM NHẤN VÀO
        if (cobe.getKey('A'))
            toaDoXe.x -= 2;

        if (cobe.getKey('D'))
            toaDoXe.x += 2;

        if (cobe.getKey(' ') && dangBanDan == 0)
        {
            // khi nhấn phím SPACE (khoảng trắng) thì bắn đạn
            dangBanDan = 1;
            toaDoDan.x = toaDoXe.x;
            toaDoDan.y = toaDoXe.y - 1;
        }

        // XỬ LÝ CHUNG (di chuyển viên đạn)
        if (dangBanDan == 1)
        {
            --toaDoDan.y;

            if (toaDoDan.y <= 0)
                dangBanDan = 0;
        }
    }

    return 0;
}
