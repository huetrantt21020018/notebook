/*
File    : 08-phaohoaB.cpp
Tác giả : Nguyễn Trung Thành - https://www.facebook.com/thanh.it95

Mô tả   : hiệu ứng pháo hoa hoàn chỉnh ở mức độ đơn giản nhất
Mục đích: demo minh họa sử dụng thư viện cobe, giúp bạn hiểu hơn về thư viện cobe
*/

#include <vector>
using namespace std;

#include "cobe.hpp"
using namespace libcobe;


CobeManager &cobe = initcobe();


int consoleWidth = 80;
int consoleHeight = 24;


/*
* Pháo hoa chạy (hàm CapNhat) sẽ trải qua 2 giai đoạn
* GIAI ĐOẠN 1. Một hạt được bắn lên
* PHÁT NỔ
* GIAI ĐOẠN 2. Lan tỏa các hạt sáng được sinh ra
* */

struct PhaoHoa
{
    int mauSac;             // màu sắc

    // giai đoạn 1
    CoVect toaDoHatSang;    // tọa độ hạt sáng được bắn lên
    CoVect toaDoNo;         // tọa độ phát nổ

    // giai đoạn 2
    int banKinhNo;          // bán kính hiện tại
    int banKinhNoMax;       // bán kính tối đa
    int thoiGianSong;       // thời gian sống < 0 nghĩa là pháo hoa đã chết
};


PhaoHoa TaoPhaoHoa()
{
    PhaoHoa phaohoa;

    phaohoa.mauSac = CoColor::getRandomColor();
    phaohoa.banKinhNo = 0;
    phaohoa.banKinhNoMax = cobe_random(3, 6);
    phaohoa.thoiGianSong = phaohoa.banKinhNoMax + 8;

    phaohoa.toaDoNo.x = cobe_random(phaohoa.banKinhNoMax + 1, consoleWidth - 2 - phaohoa.banKinhNoMax);
    phaohoa.toaDoNo.y = cobe_random(phaohoa.banKinhNoMax + 1, consoleHeight - 2 - phaohoa.banKinhNoMax);

    phaohoa.toaDoHatSang.x = phaohoa.toaDoNo.x;
    phaohoa.toaDoHatSang.y = consoleHeight;

    return phaohoa;
}


void VePhaoHoa(PhaoHoa phaohoa)
{
    cobe.setForegroundColor(phaohoa.mauSac);

    if (phaohoa.toaDoHatSang.y > phaohoa.toaDoNo.y)
    {
        // giai đoạn 1
        cobe.print(phaohoa.toaDoHatSang.x, phaohoa.toaDoHatSang.y, "#");
    }
    else
    {
        // giai đoạn 2
        int r = phaohoa.banKinhNo;
        int tamX = phaohoa.toaDoNo.x;
        int tamY = phaohoa.toaDoNo.y;

        for (int i = -r; i <= r; ++i)
        {
            cobe.print(tamX + i, tamY, "*");
            cobe.print(tamX, tamY + i, "*");
            cobe.print(tamX + i, tamY + i, "*");
            cobe.print(tamX + i, tamY - i, "*");
        }
    }
}


void HienThi(const vector<PhaoHoa> &dsphoa)
{
    for (int i = 0; i < (int)dsphoa.size(); ++i)
        VePhaoHoa(dsphoa[i]);
}


void CapNhat(vector<PhaoHoa> &dsphoa)
{
    // tạo ra pháo hoa mới, xác suất tạo pháo hoa là 1/5 = 20%
    if (dsphoa.size() < 5 && cobe_random(1, 5) == 1)
    {
        dsphoa.push_back(TaoPhaoHoa());
    }

    for (int i = (int)dsphoa.size() - 1; i >= 0; --i)
    {
        PhaoHoa &phaohoa = dsphoa[i];

        if (phaohoa.toaDoHatSang.y > phaohoa.toaDoNo.y)
        {
            // giai đoạn 1
            --phaohoa.toaDoHatSang.y;
        }
        else
        {
            // giai đoạn 2
            if (phaohoa.banKinhNo < phaohoa.banKinhNoMax)
                ++phaohoa.banKinhNo;

            --phaohoa.thoiGianSong;

            if (phaohoa.thoiGianSong < 0)
                dsphoa.erase(dsphoa.begin() + i);
        }
    }
}


int main()
{
    cobe.resizeScreen(110, 30);
    cobe.getScreenSize(consoleWidth, consoleHeight);

    vector<PhaoHoa> dsphoa;


    while (cobe.updateAndSleepFPS(25))
    {
        cobe.clearScreen();
        HienThi(dsphoa);
        CapNhat(dsphoa);
    }

    return 0;
}
