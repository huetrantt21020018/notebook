/*
File    : 03-bancovua.cpp
Tác giả : Nguyễn Trung Thành - https://www.facebook.com/thanh.it95

Mô tả   : in ra bàn cờ vua
Mục đích: demo minh họa sử dụng thư viện cobe, giúp bạn hiểu hơn về thư viện cobe
*/

#include "cobe.hpp"
using namespace libcobe;


CobeManager &cobe = initcobe();


void VeO(int y, int x, int mauSac)
{
    if (mauSac == 1)
        cobe.setBackgroundColor(CoColor::WHITE);
    else
        cobe.setBackgroundColor(CoColor::LIGHT_GRAY);

    cobe.printAndUpdate(x, y + 0, "       ");
    cobe.printAndUpdate(x, y + 1, "       ");
    cobe.printAndUpdate(x, y + 2, "       ");
}


int main()
{
    cobe.resizeScreen(90, 30);

    int chieuDoc = 4;
    int chieuNgang = 4;

    for (int y = 0; y < chieuDoc; ++y)
        for (int x = 0; x < chieuNgang; ++x)
            VeO(1 + y * 3, 1 + x * 7, (y + x) % 2);

    return 0;
}
