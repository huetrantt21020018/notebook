/*
File    : 01-color.cpp
Tác giả : Nguyễn Trung Thành - https://www.facebook.com/thanh.it95

Mô tả   : in ra màn hình các dòng chữ với vị trí và màu sắc xác định
Mục đích: demo minh họa sử dụng thư viện cobe, giúp bạn hiểu hơn về thư viện cobe
*/

#include "cobe.hpp"
using namespace libcobe;

CobeManager &cobe = initcobe();

int main()
{
    cobe.resizeScreen(80, 24);

    int x = 12345;
    cobe.printAndUpdate(1, 2, "Xin chao");
    cobe.printfAndUpdate(1, 3, "Xin chao %s %d", "Thanh", x); // giống printf trong ngôn ngữ C

    cobe.setForegroundColor(CoColor::LIGHT_CYAN);
    cobe.printAndUpdate(4, 4, "Chu mau xanh");

    cobe.setBackgroundColor(CoColor::DARK_GRAY);
    cobe.printAndUpdate(4, 5, "Chu mau xanh, nen mau xam");

    cobe.setForegroundColor(CoColor::LIGHT_YELLOW);
    cobe.printAndUpdate(4, 6, "Chu mau vang, nen mau xam");

    cobe.resetColor();
    cobe.printAndUpdate(4, 7, "Chu binh thuong");

    return 0;
}
